import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiService} from '../api.service';

@Component({
  selector: 'app-Customers-detail',
  templateUrl: './Customers-detail.component.html',
  styleUrls: ['./Customers-detail.component.css']
})
export class CustomersDetailComponent implements OnInit {

  Customers = {
    custId: String,
    custName: String,
    custMail: String,
    custPhnum: String,
    custAddr: String,
    custDOB: String,
    updated_date: String,
    _id: '/Customers-edit'
  };

  constructor(private route: ActivatedRoute, private api: ApiService, private router: Router) {
  }

  ngOnInit() {
    this.getCustomerDetails(this.route.snapshot.params['id']);
  }

  getCustomerDetails(id) {
    this.api.getCustomer(id)
      .subscribe(data => {
        console.log(data);
        this.Customers = data;
      });
  }

  deleteCustomer(id) {
    this.api.deleteCustomer(id)
      .subscribe(res => {
          this.router.navigate(['/Customers']);
        }, (err) => {
          console.log(err);
        }
      );
  }

}
