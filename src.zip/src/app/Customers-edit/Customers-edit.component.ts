import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {ApiService} from '../api.service';
import {FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators} from '@angular/forms';

@Component({
  selector: 'app-Customers-edit',
  templateUrl: './Customers-edit.component.html',
  styleUrls: ['./Customers-edit.component.css']
})
export class CustomersEditComponent implements OnInit {
  Customer = {};
  CustomerForm: FormGroup;

  matcher: any;

  constructor(private router: Router, private route: ActivatedRoute, private api: ApiService, private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.CustomerForm = this.formBuilder.group({
      'custId': [null, Validators.required],
      'custName': [null, Validators.required],
      'custMail': [null, Validators.required],
      'custPhnum': [null, Validators.required],
      'custAddr': [null, Validators.required],
      'custDOB': [null, Validators.required]
    });
    this.getCustomer(this.route.snapshot.params['id']);
  }
  getCustomerDetails(id) {
    this.api.getCustomer(id)
      .subscribe(data => {
        console.log(data);
        this.Customer = data;
      });
  }
  onFormSubmit(form: NgForm) {
    let id = this.route.snapshot.params['id'];
    console.log(form)
    this.api.updateCustomer(id, form)
      .subscribe(res => {
        this.router.navigate(['/Customers-detail', id]);
      }, (err) => {
        console.log(err);
      });
  }
  getCustomer(id) {
    this.api.getCustomer(id).subscribe(data => {
      id = data._id;
      this.CustomerForm.setValue({
        custId: data.custId,
        custName: data.custName,
        custMail: data.custMail,
        custPhnum: data.custPhnum,
        custAddr: data.custAddr,
        custDOB: data.custDOB
      });
    });
  }
}
