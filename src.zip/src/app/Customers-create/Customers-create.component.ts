import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ApiService} from '../api.service';
import {FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators} from '@angular/forms';

@Component({
  selector: 'app-book-create',
  templateUrl: './Customers-create.component.html',
  styleUrls: ['./Customers-create.component.css']
})
export class CustomersCreateComponent implements OnInit {

  CustomerForm: FormGroup;

  matcher: any;

  constructor(private router: Router, private api: ApiService, private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.CustomerForm = this.formBuilder.group({
      'custId': [null, Validators.required],
      'custName': [null, Validators.required],
      'custMail': [null, Validators.required],
      'custPhnum': [null, Validators.required],
      'custAddr': [null, Validators.required],
      'custDOB': [null, Validators.required]
    });
  }

  onFormSubmit(form: NgForm) {
    this.api.postCustomer(form)
      .subscribe(res => {
        let id = res['_id'];
        this.router.navigate(['/Customers-detail', id]);
      }, (err) => {
        console.log(err);
      });

  }
}
