import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { CustomersComponent } from './Customers/Customers.component';
import { CustomersDetailComponent } from './Customers-detail/Customers-detail.component';
import { CustomersCreateComponent } from './Customers-create/Customers-create.component';
import { CustomersEditComponent } from './Customers-edit/Customers-edit.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {
  MatInputModule,
  MatPaginatorModule,
  MatProgressSpinnerModule,
  MatSortModule,
  MatTableModule,
  MatIconModule,
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule } from '@angular/material';

const appRoutes: Routes = [
  {
    path: 'Customers',
    component: CustomersComponent,
    data: { title: 'Customer List' }
  },
  {
    path: 'Customers-detail/:id',
    component: CustomersDetailComponent,
    data: { title: 'Customer Details' }
  },
  {
    path: 'Customers-create',
    component: CustomersCreateComponent,
    data: { title: 'Create Customer' }
  },
  {
    path: 'Customers-edit/:id',
    component: CustomersEditComponent,
    data: { title: 'Edit Customer' }
  },
  { path: '',
    redirectTo: '/Customers',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    CustomersComponent,
    CustomersDetailComponent,
    CustomersCreateComponent,
    CustomersEditComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
